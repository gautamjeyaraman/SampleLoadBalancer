Assuming you are working out of the directory in which the executable exists, the server for port 8001 can be executed as:

server.exe 8001 <fully qualified name of server load file>